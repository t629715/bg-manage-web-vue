<template>
    <div id="content">
      <div id="content-header">
        <div id="breadcrumb"> <a href="javascript:;" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> 客户管理</a> <a href="javascript:;" class="current">客户分析</a> </div>
        <h1></h1>
      </div>
      <div class="container-fluid">
        理财交易

      </div>
    </div>
</template>

<script>
    export default {
        data: function(){
            return {}
        }
    }
</script>

<style scoped>

</style>
