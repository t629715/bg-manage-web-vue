<template>
	<div id="content">
		<div >
			<div class="title">实名认证</div>

		</div>
	</div>
</template>

<script>

</script>
<style type="text/css">

</style>
