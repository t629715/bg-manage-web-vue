<template>
    <div class="hello">
          <img class="mr25" src="../../../static/img/Admin.png" width="200px" alt="Logo" />
    </div>
</template>

<script >
export default {
    data() {
        return {
        }
    },

}
</script>

<style scoped>

  .hello{
    width: 100%;
    height: 100%;
    background: #31252b!important;
    font-size: 40px;
    color: blue;
    text-align: center;
    padding-top:200px;
  }
</style>
